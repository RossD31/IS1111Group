import csv  # Importing the csv module for reading and writing CSV files.
import customtkinter as ctk  # Importing a custom module named customtkinter as ctk.
from PIL import Image  # Importing the Image module from the PIL library.

ctk.set_default_color_theme("green")  # Setting the default color theme for the custom tkinter module to green.

class OrderConfirmation:  # Defining a class named OrderConfirmation.
    def __init__(self, root):  # Defining the constructor method for the class.
        self.root = root  # Assigning the passed root parameter to the instance variable root.
        self.root.title("Order Confirmation")  # Setting the title of the root window to "Order Confirmation".
        self.root.geometry("1400x800")  # Setting the geometry of the root window to 1400x800.
        self.root.config(bg="#f2e4dc")  # Configuring the background color of the root window to a light shade.

        # Adjust container size
        container_width = 800  # Setting the width of the container.
        container_height = 600  # Setting the height of the container.

        # Creating a container using the custom tkinter module with specified properties.
        self.container = ctk.CTkLabel(master=root, text="", bg_color="#f2e4dc", fg_color="#F2A007", height=container_height, width=container_width, corner_radius=10)
        self.container.place(relx=0.5, rely=0.5, anchor=ctk.CENTER)  # Placing the container in the center of the root window.
        
        # Reading order details from current-customer.csv
        order_details = self.read_order_details()  # Calling a method to read order details.
        order_number = order_details[0]  # Extracting the order number from the order details.
        customer_name = f"{order_details[1]} {order_details[2]}"  # Concatenating first and last name to get customer name.
        delivery_address = order_details[5]  # Extracting delivery address from the order details.

        # Creating and placing labels to display order information.
        text_label = ctk.CTkLabel(self.root, text=f"Order Number: {order_number}, is confirmed", font=("Helvetica", 22, "bold"), bg_color="#F2A007")
        text_label.place(relx=0.51, rely=0.1, anchor=ctk.CENTER)
        
        text_label = ctk.CTkLabel(self.root, text=f"Customer Name: {customer_name}", font=("Helvetica", 20), bg_color="#F2A007")
        text_label.place(relx=0.5, rely=0.2, anchor=ctk.CENTER)

        text_label = ctk.CTkLabel(self.root, text=f"Delivery Address: {delivery_address}", font=("Helvetica", 20), bg_color="#F2A007")
        text_label.place(relx=0.5, rely=0.3, anchor=ctk.CENTER)
        
        # Display "Purchases" heading
        purchases_label = ctk.CTkLabel(self.root, text="Purchases", font=("Helvetica", 22, "bold"), bg_color="#F2A007")
        purchases_label.place(relx=0.5, rely=0.4, anchor=ctk.CENTER)
        
        # Reading receipt details from receipt-items.csv
        receipt_details = self.read_receipt_details()  # Calling a method to read receipt details.
        receipt_text = '\n'.join(receipt_details)  # Joining receipt details into a single string with newline separators.
        
        # Displaying list of items in a label.
        receipt_label = ctk.CTkLabel(self.root, text=receipt_text, font=("Helvetica", 20), bg_color="#F2A007", wraplength=container_width * 0.8)
        receipt_label.place(relx=0.5, rely=0.5, anchor=ctk.CENTER)
        
        # Calculating total and VAT
        total_amount = sum([float(row.split(': ')[1]) for row in receipt_details])  # Calculating total amount from receipt details.
        vat_amount = total_amount * 0.23  # Calculating VAT amount (23% of total).

        #Checking if this order was a delivery or collection
        with open("current-customer.csv",mode="r") as file: #This opens the current-customer csv file, and checks to see if theres a "D" in the method row, indicating delivery
            read=csv.reader(file)
            next(read)
            for line in read:
             if line[6]=="D":
                    total_amount+=2.50 #If its found, an additional charge of 2.50 is added to the total price, and the user is shown this with the label below
                    delivery_charge=ctk.CTkLabel(self.root,text='Delivery Charge: €2.50',font=("Helvetica",20), bg_color="#F2A007")
                    delivery_charge.place(relx=0.5,rely=0.75,anchor=ctk.CENTER)
            else:
                pass
        if total_amount >= 35: #If the total is above 35 euro, the user will recieve a price of 35 euro
            discount=total_amount*0.1
            total_amount-=discount

        # Displaying total and VAT in labels.
        total_label = ctk.CTkLabel(self.root, text=f"Total: {total_amount:.2f} EUR", font=("Helvetica", 20), bg_color="#F2A007")
        total_label.place(relx=0.5, rely=0.8, anchor=ctk.CENTER)
        
        vat_label = ctk.CTkLabel(self.root, text=f"VAT (23%): {vat_amount:.2f} EUR", font=("Helvetica", 20), bg_color="#F2A007")
        vat_label.place(relx=0.5, rely=0.85, anchor=ctk.CENTER)
        
        # Adding a logo image to the GUI.
        imagelogo = ctk.CTkImage(Image.open("logo2.png"), size=(180, 180))
        logo = ctk.CTkLabel(master=self.root, text="", corner_radius=10, image=imagelogo, bg_color="#f2e4dc")
        logo.place(x=0, y=0)
        
        # Adding a button for creating a new order.
        new_order_button = ctk.CTkButton(master=root, text="New Order", command=self.new_order, bg_color="#F2A007")
        new_order_button.place(relx=0.45, rely=0.9)

    def read_order_details(self):  # Method to read order details from a CSV file.
        with open('current-customer.csv', mode='r') as file:  # Opening current-customer.csv file in read mode.
            reader = csv.reader(file)  # Creating a CSV reader object.
            next(reader)  # Skipping the header row.
            order_details = next(reader)  # Reading the order details from the file.
            return order_details  # Returning the order details.

    def read_receipt_details(self):  # Method to read receipt details from a CSV file.
        receipt_details = []  # Initializing an empty list for receipt details.
        with open('receipt-items.csv', mode='r') as file:  # Opening receipt-items.csv file in read mode.
            reader = csv.reader(file)  # Creating a CSV reader object.
            next(reader)  # Skipping the header row.
            for row in reader:  # Iterating through each row in the CSV file.
                item = row[0]  # Extracting the item name from the row.
                price = row[1]  # Extracting the price from the row.
                receipt_details.append(f"{item}: {price}")  # Appending item and price to the receipt details list.
        return receipt_details  # Returning the receipt details list.

    def new_order(self):  # Method to create a new order.
        root.destroy()  # Destroying the current root window.
        import DeliveryCollection  # Importing the DeliveryCollection module.
        DeliveryCollection.DeliveryCollection1(app)  # Creating a new instance of DeliveryCollection.
        app.mainloop()  # Starting the main loop.

root = ctk.CTk()  # Creating the root window using custom tkinter module.
app = OrderConfirmation(root)  # Creating an instance of the OrderConfirmation class.
root.mainloop()  # Starting the main loop of the GUI application.