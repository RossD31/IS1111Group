#import modules 
import customtkinter as ctk
from tkinter import messagebox
from PIL import Image
import csv

#Sets default colour scheme for customtkinter
ctk.set_default_color_theme("green")

class DeliveryCollection1():
    def __init__(self, root):
        self.root = root
        self.root.title("Delivery and Collection")
        self.root.geometry("1400x800")
        self.root.config(bg="#f2e4dc")
        self.buttons()
      
    def buttons(self):
        self.delivery_button = ctk.CTkButton(master=self.root, text="Delivery", corner_radius=10, command=self.deliver_order,
                                         width=360, height=600, border_width=0,
                                         font=("Helvetica", 40, "bold"),
                                         fg_color="#F2A007", bg_color="#f2e4dc")
        self.delivery_button.place(relx=0.4, rely=0.55, anchor=ctk.CENTER)
        self.delivery_button.configure(state="disabled")
        #creating collection button
        self.collection_button = ctk.CTkButton(master=self.root, text="Collection", corner_radius=10, command=self.collect_order,
                                           width=360, height=600, border_width=0,
                                           font=("Helvetica", 40, "bold"),
                                           fg_color="#F27649", bg_color="#f2e4dc")
        self.collection_button.place(relx=0.7, rely=0.55, anchor=ctk.CENTER)
        self.collection_button.configure(state="disabled")

        #adding logo 
        imagelogo = ctk.CTkImage(Image.open("logo2.png"), size=(180, 180))
        logo = ctk.CTkLabel(master=self.root, text="", corner_radius=10, image=imagelogo, bg_color="#f2e4dc")
        logo.place(x=0, y=0)
        #creating entry for area code 
        self.area = ctk.CTkEntry(master=self.root, placeholder_text="Area Code", corner_radius=10, border_width=0, width=90)
        self.area.place(relx=0.44, rely=0.08, anchor=ctk.CENTER)
        #creating entry for phone number 
        self.number_entry = ctk.CTkEntry(master=self.root, placeholder_text="Customers Phone Number", corner_radius=10, border_width=0, width=200)
        self.number_entry.place(relx=0.55, rely=0.08, anchor=ctk.CENTER)
        #creating submit button 
        submit_button = ctk.CTkButton(master=self.root, text="Submit", command=self.submit_phone, width=10, corner_radius=10)
        submit_button.place(relx=0.65, rely=0.08, anchor=ctk.CENTER)
    #method to handle delivery button click 
    def deliver_order(self):
            


        print("Delivery button clicked")
        root.destroy()
        import DeliveryDetails
        DeliveryDetails.delivery(root)
        root.mainloop()
    #method to handle button collection click 
    def collect_order(self):
        data = {
                "Method": "C"
            }
        with open("customer-details.csv","a",newline="") as file:
            writer=csv.DictWriter(file,fieldnames=data.keys())
            writer.writerow(data)
        print("Collection button clicked")
        root.destroy()
        import CollectionDetails
        
        CollectionDetails.GUI_collection(root)
        root.mainloop()
    #method to submit phone number
    def submit_phone(self):
        area_code = self.area.get()
        if area_code.strip() == "" or not area_code.isdigit() or len(area_code) != 3:
            messagebox.showerror("Error", "Please enter a valid area code with 3 digits.")
            return

        phone_number = self.number_entry.get()      #acquires phone number from entry 
        if phone_number.strip() == "" or not phone_number.isdigit() or len(phone_number) != 9:
            messagebox.showerror("Error", "Please enter a valid phone number with 9 digits.")       #error message is displayed if invalid input is entered
            return 

        print("Area code:", area_code)                              #print area code
        print("Phone number:", phone_number)      
        self.delivery_button.configure(state="normal")
        self.collection_button.configure(state="normal")                  #print phone number

        app.autofill_by_phone_number(phone_number)                  #call method from from app object

root = ctk.CTk()                                                    #creates root window 
app = DeliveryCollection1(root)                               
root.mainloop()                                                     #runs gui application

#==========================================================================
#REFERENCES:
#Title: Customtkinter
#Author:TomSchimansky
#Date: 23/02/24
#Code Version: 5.2.2
#Availability: https://pypi.org/project/customtkinter/0.3/#files
