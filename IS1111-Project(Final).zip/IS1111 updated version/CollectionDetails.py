
# Importing necessary libraries/modules
import customtkinter as ctk  # Custom tkinter module
from PIL import Image, ImageTk  # Image processing libraries

import random  # For generating random numbers
import csv  # For working with CSV files
import phonenumbers  # For phone number validation

# Setting default color theme
ctk.set_default_color_theme("green")

# Setting appearance mode
ctk.set_appearance_mode("light")

# Class for GUI collection
class GUI_collection():

    def __init__(self, root_tk):
        # Initializing GUI
        self.root_tk = root_tk
        self.root_tk.geometry("700x700")  # Setting window size
        self.root_tk.title("CustomTkinter Test")  # Setting window title
        self.root_tk.config(bg="#f2e4dc")  # Setting background color

        placeholder_font=("Verdana",16)  # Font for placeholder text

        # Creating entries for first and last name
        self.fname_entry=ctk.CTkEntry(master=root_tk,placeholder_text="First Name:",corner_radius=10,height=50,width=150,font=placeholder_font,border_width=0, bg_color="#f2e4dc")
        self.fname_entry.place(relx=0.3,rely=0.04) # Placing the input field using relax and relay

        self.lname_entry=ctk.CTkEntry(master=root_tk,placeholder_text="Last Name:",corner_radius=10,height=50,width=150,font=placeholder_font,border_width=0, bg_color="#f2e4dc")
        self.lname_entry.place(relx=0.57,rely=0.04) # Placing the input field using relax and relay

        # Creating entries for area code and phone number
        self.area_code=ctk.CTkEntry(master=root_tk,placeholder_text="Area Code",corner_radius=10,height=50,width=100,font=placeholder_font,border_width=0,bg_color="#f2e4dc")
        self.area_code.place(relx=0.3,rely=0.15) # Placing the input field using relax and relay
        
        self.number=ctk.CTkEntry(master=root_tk,placeholder_text="Phone Number",corner_radius=10,height=50,width=150,font=placeholder_font,border_width=0, bg_color="#f2e4dc") 
        self.number.place(relx=0.57,rely=0.15)

        # Creating entry for order notes and customer notes
        self.ordernotes=ctk.CTkEntry(master=root_tk,placeholder_text="ORDER NOTES:",corner_radius=10,height=100,width=250,font=placeholder_font,border_width=0, bg_color="#f2e4dc")
        self.ordernotes.place(relx=0.15,rely=0.3) # Placing the input field using relax and relay

        self.customernotes=ctk.CTkEntry(master=root_tk,placeholder_text="CUSTOMER NOTES:",font=placeholder_font,corner_radius=10,height=100,width=250,border_width=0, bg_color="#f2e4dc")
        self.customernotes.place(relx=0.55,rely=0.3) # Placing the input field using relax and relay

        # Creating submit button
        self.submit_button=ctk.CTkButton(master=root_tk,text="Submit",command=self.submit, bg_color="#f2e4dc")
        self.submit_button.place(relx=0.4,rely=0.5) # Placing the button using relax and relay

        # Adding logo
        self.img=ctk.CTkImage(Image.open("logo2.png"),size=(150,150))
        self.logo=ctk.CTkLabel(master=root_tk,text="",corner_radius=10,image=self.img,bg_color="#f2e4dc")
        self.logo.place(x=0,y=0) # Placing the logo in the top left corner

    # Function to handle submit action
    def submit(self):
        # Check if the inputs for first and last name are good
        fname_valid = self.validation_name_checker(self.fname_entry.get())
        lname_valid = self.validation_name_checker(self.lname_entry.get())

        # Check if the inputs for area code and number are valid
        area_code_valid = self.validate_area_code(self.area_code.get())
        number_valid = self.validate_phone_number(self.number.get())

        # If all inputs are valid, proceed
        if fname_valid and lname_valid and area_code_valid and number_valid:
            receipt_number = self.generate_receipt_number()

            # Collect all valid inputs
            data = {
                "Receipt Number": receipt_number,
                "First Name": self.fname_entry.get(),
                "Last Name": self.lname_entry.get(),
                "Area Code": self.area_code.get(),
                "Phone Number": self.number.get(),
                "Address": "",
                "Method": "C"
            }

            # Write data to CSV file
            with open('customer-details.csv', mode='a', newline='') as file:
                writer = csv.DictWriter(file, fieldnames=data.keys())

                # If the file is empty, write headers
                if file.tell() == 0:
                    writer.writeheader()

                # Write data to the file
                writer.writerow(data)
                root_tk.destroy()
                import MenuPage
                MenuPage.Menu(app)
                app.mainloop()

    # Function to validate area code
    def validate_area_code(self, country_input):
        try:
            # Check if the country code is valid
            if not phonenumbers.region_code_for_country_code(int(country_input)):
                return False
        except ValueError:
            return False
        return True

    # Function to validate phone number
    def validate_phone_number(self, number):
        if not number.isdigit() or len(number) != 9:
            return False
        return True

    # Function to get customer info by receipt number
    def get_customer_info_by_receipt(self, receipt_number):
        # Search for customer information by receipt number
        with open('customer-details.csv', mode='r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row["Receipt Number"] == receipt_number:
                    return {
                        "Receipt Number": row["Receipt Number"],
                        "First Name": row["First Name"],
                        "Last Name": row["Last Name"],
                        "Area Code": row["Area Code"],
                        "Phone Number": row["Phone Number"]
                    }
        return None  # Return None if receipt number not found

    # Function to generate receipt number
    def generate_receipt_number(self):
        # Generate a random receipt number between 1 and 10000
        receipt_number = random.randint(1, 10000)
        return receipt_number
    
    # Function to check validation of name
    def validation_name_checker(self, name):
        if len(name.strip()) > 30 or len(name.strip()) == 0:
            # Print error message if name is too long
            print("\nSorry your name is too long long.")
            return False
        return True

# Creating root Tkinter window
root_tk=ctk.CTk()

# Creating application instance
app=GUI_collection(root_tk)

# Running main loop
root_tk.mainloop()