import customtkinter as ctk
from tkinter import messagebox
from PIL import Image


ctk.set_default_color_theme("green")

class DeliveryCollection1():
    def __init__(self, root):
        self.root = root
        root.after(201,lambda :root.iconbitmap('logo2.ico'))
        self.root.title("Delivery and Collection")
        self.root.geometry("1400x800")
        self.root.config(bg="#f2e4dc")
        self.buttons()

    def buttons(self):
        self.delivery_button = ctk.CTkButton(master=self.root, text="Delivery", corner_radius=10, command=self.deliver_order,
                                         width=360, height=600, border_width=0,
                                         font=("Helvetica", 40, "bold"),
                                         fg_color="#F2A007", bg_color="#f2e4dc")
        self.delivery_button.place(relx=0.4, rely=0.55, anchor=ctk.CENTER)
        self.delivery_button.configure(state="disabled")

        self.collection_button = ctk.CTkButton(master=self.root, text="Collection", corner_radius=10, command=self.collect_order,
                                           width=360, height=600, border_width=0,
                                           font=("Helvetica", 40, "bold"),
                                           fg_color="#F27649", bg_color="#f2e4dc")
        self.collection_button.place(relx=0.7, rely=0.55, anchor=ctk.CENTER)
        self.collection_button.configure(state="disabled")
        self.prompt=ctk.CTkLabel(master=root,text="Please Enter Number",height=30,width=60,corner_radius=10,bg_color="#f2e4dc",font=("Helvetica",20),fg_color="#f57242")
        self.prompt.place(relx=0.45,rely=0.01)


        
        imagelogo = ctk.CTkImage(Image.open("logo2.png"), size=(180, 180))
        logo = ctk.CTkLabel(master=self.root, text="", corner_radius=10, image=imagelogo, bg_color="#f2e4dc")
        logo.place(x=0, y=0)

        self.area = ctk.CTkEntry(master=self.root, placeholder_text="Area Code", corner_radius=10, border_width=0, width=90)
        self.area.place(relx=0.44, rely=0.08, anchor=ctk.CENTER)

        self.number_entry = ctk.CTkEntry(master=self.root, placeholder_text="Customers Phone Number", corner_radius=10, border_width=0, width=200)
        self.number_entry.place(relx=0.55, rely=0.08, anchor=ctk.CENTER)

        submit_button = ctk.CTkButton(master=self.root, text="Submit", command=self.submit_phone, width=10, corner_radius=10)
        submit_button.place(relx=0.65, rely=0.08, anchor=ctk.CENTER)

    def deliver_order(self):
        print("Delivery button clicked")
        root.destroy()
        import DeliveryDetails
        DeliveryDetails.delivery(root)
        root.mainloop()

    def collect_order(self):
        print("Collection button clicked")
        root.destroy()
        import CollectionDetails
        
        CollectionDetails.GUI_collection(root)
        root.mainloop()

    def submit_phone(self):
        
        area_code = self.area.get()
        if area_code.strip() == "" or not area_code.isdigit() or len(area_code) != 3:
            messagebox.showerror("Error", "Please enter a valid area code with 3 digits.")
            return

        phone_number = self.number_entry.get()
        if phone_number.strip() == "" or not phone_number.isdigit() or len(phone_number) != 9:
            messagebox.showerror("Error", "Please enter a valid phone number with 9 digits.")
            return

        print("Area code:", area_code)
        print("Phone number:", phone_number)
        self.delivery_button.configure(state="normal")
        self.collection_button.configure(state="normal")
        self.prompt.place_forget()

root = ctk.CTk()
app = DeliveryCollection1(root)
root.mainloop()
