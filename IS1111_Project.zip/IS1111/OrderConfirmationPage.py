import customtkinter as ctk
from PIL import Image, ImageTk
ctk.set_default_color_theme("green")


class OrderConfirmation:
    def __init__(self,root):
        self.root=root
        self.root.title("Order Confirmation")
        self.root.geometry("1400x800")
        self.root.config(bg="#f2e4dc")

        self.container=ctk.CTkLabel(master=root,text="",bg_color="#f2e4dc",fg_color="#F2A007",height=500,width=500,corner_radius=10)
        self.container.place(relx=0.5,rely=0.5,anchor=ctk.CENTER)
        
        text_label = ctk.CTkLabel(self.root, text="Order Number: , is confirmed", font=("Helvetica", 22, "bold"),bg_color="#F2A007")
        text_label.place(relx=0.51, rely=0.2, anchor=ctk.CENTER)
        
        text_label = ctk.CTkLabel(self.root, text="Print receipt here", font=("Helvetica", 20),bg_color="#F2A007")
        text_label.place(relx=0.5, rely=0.4, anchor=ctk.CENTER)
        
        imagelogo = ctk.CTkImage(Image.open("logo2.png"), size=(180, 180))
        logo = ctk.CTkLabel(master=self.root, text="", corner_radius=10, image=imagelogo, bg_color="#f2e4dc")
        logo.place(x=0, y=0)
        
        new_order_button = ctk.CTkButton(master=root, text="New Order", command=self.new_order,bg_color="#F2A007")
        new_order_button.place(relx=0.45, rely=0.5)

    
    def new_order(self):
        root.destroy()
        import DeliveryCollection
        DeliveryCollection.DeliveryCollection1(app)
        app.mainloop()
        

root=ctk.CTk()
app=OrderConfirmation(root)
root.mainloop()