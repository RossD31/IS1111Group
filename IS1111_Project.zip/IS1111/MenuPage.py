import customtkinter as ctk
from PIL import Image, ImageTk
import time

ctk.set_default_color_theme("green")

class Menu():
    def __init__(self,root_tk):
        self.root_tk = root_tk
        self.root_tk.geometry("800x800")
        self.root_tk.title("Menu")
        self.root_tk.config(bg="#f2e4dc")
        fontType=("Verdana",20)
        extras_Font=("Verdana",16)
        self.reciept=[]
        self.size=""
        self.price=0


        self.customer_details = ctk.CTkButton(master=root_tk, text="Customer Details", corner_radius=10, font=fontType, bg_color="#f2e4dc", command=self.go_back_to_customer_details)
        self.customer_details.place(relx=0.4, rely=0.05, anchor=ctk.CENTER)

        self.undo = ctk.CTkButton(master=root_tk, text="Undo Pizza", corner_radius=10, font=fontType, bg_color="#f2e4dc", command=self.undo)
        self.undo.place(relx=0.615, rely=0.05, anchor=ctk.CENTER)

        self.another = ctk.CTkButton(master=root_tk, text="Another Pizza", corner_radius=10, font=fontType, bg_color="#f2e4dc", command=self.reset_pizza_buttons)
        self.another.place(relx=0.81, rely=0.05, anchor=ctk.CENTER)

        self.removed=ctk.CTkLabel(master=root_tk,text="Removed Item from Order!",height=70,width=20,font=fontType,corner_radius=10,bg_color="#f2e4dc",fg_color="#3ac25c")
        self.removed.place_forget()

    

        self.imagelogo = ctk.CTkImage(Image.open("logo2.png"), size=(180, 180))
        self.logo = ctk.CTkLabel(master=root_tk, text="", corner_radius=10, image=self.imagelogo,bg_color="#f2e4dc")
        
        self.logo.place(x=0, y=0)

        self.small = ctk.CTkButton(master=root_tk, text="Small",corner_radius=10,height=85,width=150,font=fontType,fg_color="#f2785c",bg_color="#f2e4dc",command=self.small_button)
        self.small.place(relx=0.125, rely=0.35, anchor=ctk.CENTER)

        self.medium = ctk.CTkButton(master=root_tk, text="Medium",corner_radius=10,font=fontType,height=85,width=150,bg_color="#f2e4dc",fg_color="#f2785c",command=self.medium_button) 
        self.medium.place(relx=0.125, rely=0.5, anchor=ctk.CENTER)
        
        self.large = ctk.CTkButton(master=root_tk, text="Large", width=150,corner_radius=10,height=85,font=fontType,bg_color="#f2e4dc",fg_color="#f2785c",command=self.large_button)
        self.large.place(relx=0.125, rely=0.65, anchor=ctk.CENTER)
        #====================================================================================================================================================

        self.margherita = ctk.CTkButton(master=root_tk, text="Margherita",corner_radius=10,height=125,width=125,font=fontType,fg_color="#F2A007",bg_color="#f2e4dc",command=self.margherita_button)
        self.margherita.place(relx=0.4, rely=0.22, anchor=ctk.CENTER)

        self.pepperoni = ctk.CTkButton(master=root_tk, text="Pepperoni",corner_radius=10,font=fontType,height=125,width=125,bg_color="#f2e4dc",fg_color="#F2A007",command=self.pepperoni_button) 
        self.pepperoni.place(relx=0.4, rely=0.42, anchor=ctk.CENTER)
        
        self.fourSeasons = ctk.CTkButton(master=root_tk, text="Four\nSeasons", width=125,corner_radius=10,height=125, font=fontType,bg_color="#f2e4dc",fg_color="#F2A007",command=self.fourSeasons_button)
        self.fourSeasons.place(relx=0.4, rely=0.622, anchor=ctk.CENTER)

        self.icon=ctk.CTkImage(Image.open("checked.png"),size=(90,90))
        self.confirm=ctk.CTkButton(master=root_tk,text="",width=800,height=20,image=self.icon,bg_color="#f2e4dc",fg_color="#3ac25c",corner_radius=0,border_color="#f2e4dc",border_width=0, command=self.confirmation_page)
        self.confirm.place(relx=0.5,rely=0.8,anchor=ctk.CENTER)

        self.added=ctk.CTkLabel(master=root_tk,text="Added to Order!",height=70,width=20,font=fontType,corner_radius=10,bg_color="#f2e4dc",fg_color="#3ac25c")
        self.added.place_forget()

        



        #====================================================================================================================================================
        
        self.Rucola = ctk.CTkButton(master=root_tk, text="Rucola",corner_radius=10,height=65,width=150,font=extras_Font,fg_color="#F27649",bg_color="#f2e4dc",command=self.rucola)
        self.Rucola.place(relx=0.6, rely=0.35, anchor=ctk.CENTER)

        self.Mushrooms = ctk.CTkButton(master=root_tk, text="Mushrooms",corner_radius=10,height=65,width=150,font=extras_Font,fg_color="#F27649",bg_color="#f2e4dc",command=self.mushrooms)
        self.Mushrooms.place(relx=0.6, rely=0.45, anchor=ctk.CENTER)

        self.garlic = ctk.CTkButton(master=root_tk, text="Garlic dip",corner_radius=10,height=65,width=150,font=extras_Font,fg_color="#F27649",bg_color="#f2e4dc",command=self.Garlic_dip)
        self.garlic.place(relx=0.6, rely=0.55, anchor=ctk.CENTER)

        self.mayo = ctk.CTkButton(master=root_tk, text="Spicy garlic mayo",corner_radius=10,height=65,width=150,font=extras_Font,fg_color="#F27649",bg_color="#f2e4dc",command=self.spicy_garlic)
        self.mayo.place(relx=0.6, rely=0.65, anchor=ctk.CENTER)

        self.Coke = ctk.CTkButton(master=root_tk, text="Coke",corner_radius=10,height=65,width=150,font=extras_Font,fg_color="#F27649",bg_color="#f2e4dc",command=self.coke)
        self.Coke.place(relx=0.8, rely=0.35, anchor=ctk.CENTER)

        self.Fanta = ctk.CTkButton(master=root_tk, text="Fanta",corner_radius=10,height=65,width=150,font=extras_Font,fg_color="#F27649",bg_color="#f2e4dc",command=self.fanta)
        self.Fanta.place(relx=0.8, rely=0.45, anchor=ctk.CENTER)

        self.Sprite = ctk.CTkButton(master=root_tk, text="Sprite",corner_radius=10,height=65,width=150,font=extras_Font,fg_color="#F27649",bg_color="#f2e4dc",command=self.fanta)
        self.Sprite.place(relx=0.8, rely=0.55, anchor=ctk.CENTER)

        self.Water = ctk.CTkButton(master=root_tk, text="Water",corner_radius=10,height=65,width=150,font=extras_Font,fg_color="#F27649",bg_color="#f2e4dc",command=self.water)
        self.Water.place(relx=0.8, rely=0.65, anchor=ctk.CENTER)
#===============================================================================================================================================================================

    def small_button(self):

        self.small.configure(state='normal')
        self.medium.configure(state='disabled')
        self.large.configure(state='disabled')
        
        if True:
            self.size="Small"
        return self.size
    

        
    def medium_button(self):

        self.small.configure(state='disabled')
        self.medium.configure(state='normal')
        self.large.configure(state='disabled')
        
        if True:
            self.size="Medium"
        return self.size
        
    def large_button(self):

        self.small.configure(state='disabled')
        self.medium.configure(state='disabled')
        self.large.configure(state='normal')

        if True:
            self.size="Large"
        return self.size
        
    def margherita_button(self):

        self.margherita.configure(state='normal')
        self.pepperoni.configure(state='disabled')
        self.fourSeasons.configure(state='disabled')
    
        if self.size=="Small":
            self.price=10
        if self.size=="Medium":
            self.price=12
        if self.size=="Large":
            self.price==15
        self.reciept.append(f'{self.size} Margherita: €{self.price}\n')
        self.added_to_order()
    

    def pepperoni_button(self):


        self.margherita.configure(state='disabled')
        self.pepperoni.configure(state='normal')
        self.fourSeasons.configure(state='disabled')

        if self.size=="Small":
            self.price=12
        if self.size=="Medium":
            self.price=14
        if self.size=="Large":
            self.price==17
        self.reciept.append(f'{self.size} Pepperoni: €{self.price}\n')
        self.added_to_order()
        

    def fourSeasons_button(self):
        
        self.margherita.configure(state='disabled')
        self.pepperoni.configure(state='disabled')
        self.fourSeasons.configure(state='normal')
    
        if self.size=="Small":
            self.price=11.50
        if self.size=="Medium":
            self.price=13.50
        if self.size=="Large":
            self.price==16.50
        self.reciept.append(f'{self.size} Four-Seasons: €{self.price}\n')
        self.added_to_order()
    
    def added_to_order(self):
        if True:
            self.added.place(relx=0.6,rely=0.16)
            self.root_tk.after(1000,self.hide_label)
    def hide_label(self):
        self.added.place_forget()

    def removed_from_order(self):
        if True:
            self.removed.place(relx=0.517,rely=0.16)
            self.root_tk.after(1000,self.hide_removed)
    def hide_removed(self):
        self.removed.place_forget()
        


    def reset_pizza_buttons(self):

        self.margherita.configure(state='normal')
        self.pepperoni.configure(state='normal')
        self.fourSeasons.configure(state='normal')
        self.small.configure(state='normal')
        self.medium.configure(state='normal')
        self.large.configure(state='normal')

    def undo(self):
        
        self.margherita.configure(state='normal')
        self.pepperoni.configure(state='normal')
        self.fourSeasons.configure(state='normal')
        self.small.configure(state='normal')
        self.medium.configure(state='normal')
        self.large.configure(state='normal')
        self.removed_from_order()
        self.last_added=self.reciept[-1]
        self.reciept.remove(self.last_added)
        



        # PRAISE CAN IMPLEMENT REMOVAL OF PIZZA ON CURRENT RECEIPT

    def go_back_to_customer_details(self):
            root_tk.destroy()
            import DeliveryDetails
            DeliveryDetails.delivery(app)
            app.mainloop()

        

    def confirmation_page(self):

        root_tk.destroy() 
        import OrderConfirmationPage
        OrderConfirmationPage.OrderConfirmation(app)
        app.mainloop()
        
        


    def rucola(self):
        self.price=1.50
        self.reciept.append(f'Rucola, €{self.price}')
        self.added_to_order()
    def mushrooms(self):
        self.price=2
        self.reciept.append(f'Mushrooms, €{self.price}')
        self.added_to_order()
    def Garlic_dip(self):
        self.price=3
        self.reciept.append(f'Garlic Dip, €{self.price}\n')
        self.added_to_order()
    def spicy_garlic(self):
        self.price=3
        self.reciept.append(f'Spicy Garlic Dip, €{self.price}')
        self.added_to_order()

    def coke(self):
        self.price=2
        self.reciept.append(f'Coca Cola, €{self.price}')
        self.added_to_order()

    def fanta(self):
        self.price=2
        self.reciept.append(f'Fanta, €{self.price}')
        self.added_to_order()

    def sprite(self):
        self.price=2
        self.reciept.append(f'Sprite, €{self.price}')
        self.added_to_order()

    def water(self):
        self.price=1.5
        self.reciept.append(f'Water, €{self.price}')
        self.added_to_order()

    def print_reciept(self):
        print(self.reciept)
    


    

        






 

 


        
        

            
            



root_tk=ctk.CTk()
app=Menu(root_tk)
root_tk.mainloop()
    
