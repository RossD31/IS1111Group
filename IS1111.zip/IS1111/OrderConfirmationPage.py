import customtkinter as ctk
from PIL import Image, ImageTk


class OrderConfirmation:
    def __init__(self,root):
        self.root=root
        self.root.title("Order Confirmation")
        self.root.geometry("1400x800")
        self.root.config(bg="#f2e4dc")
        
        text_label = ctk.CTkLabel(self.root, text="Order Number: , is confirmed", font=("Helvetica", 22, "bold"))
        text_label.place(relx=0.52, rely=0.2, anchor=ctk.CENTER)
        
        text_label = ctk.CTkLabel(self.root, text="Print receipt here", font=("Helvetica", 20))
        text_label.place(relx=0.52, rely=0.4, anchor=ctk.CENTER)
        
        imagelogo = ctk.CTkImage(Image.open("logo2.png"), size=(180, 180))
        logo = ctk.CTkLabel(master=self.root, text="", corner_radius=10, image=imagelogo, bg_color="#f2e4dc")
        logo.place(x=0, y=0)
        
        new_order_button = ctk.CTkButton(master=root, text="New Order", command=self.new_order)
        new_order_button.place(relx=0.5, rely=0.5)

    
    def new_order(self):
        root.destroy()
        import DeliveryCollection
        DeliveryCollection.DeliveryCollection1(app)
        app.mainloop()
        

root=ctk.CTk()
app=OrderConfirmation(root)
root.mainloop()