import csv
import customtkinter as ctk
from PIL import Image

ctk.set_default_color_theme("green")

class OrderConfirmation:
    def __init__(self, root):
        self.root = root
        self.root.title("Order Confirmation")
        self.root.geometry("1400x800")
        self.root.config(bg="#f2e4dc")

        # Adjust container size
        container_width = 800
        container_height = 600

        self.container = ctk.CTkLabel(master=root, text="", bg_color="#f2e4dc", fg_color="#F2A007", height=container_height, width=container_width, corner_radius=10)
        self.container.place(relx=0.5, rely=0.5, anchor=ctk.CENTER)
        
        # Read order details from current-customer.csv
        order_details = self.read_order_details()
        order_number = order_details[0]
        customer_name = f"{order_details[1]} {order_details[2]}"
        delivery_address = order_details[5]

        text_label = ctk.CTkLabel(self.root, text=f"Order Number: {order_number}, is confirmed", font=("Helvetica", 22, "bold"), bg_color="#F2A007")
        text_label.place(relx=0.51, rely=0.1, anchor=ctk.CENTER)
        
        text_label = ctk.CTkLabel(self.root, text=f"Customer Name: {customer_name}", font=("Helvetica", 20), bg_color="#F2A007")
        text_label.place(relx=0.5, rely=0.2, anchor=ctk.CENTER)

        text_label = ctk.CTkLabel(self.root, text=f"Delivery Address: {delivery_address}", font=("Helvetica", 20), bg_color="#F2A007")
        text_label.place(relx=0.5, rely=0.3, anchor=ctk.CENTER)
        
        # Display "Purchases" heading
        purchases_label = ctk.CTkLabel(self.root, text="Purchases", font=("Helvetica", 22, "bold"), bg_color="#F2A007")
        purchases_label.place(relx=0.51, rely=0.4, anchor=ctk.CENTER)
        
        # Read receipt details from receipt-items.csv
        receipt_details = self.read_receipt_details()
        receipt_text = '\n'.join(receipt_details)
        
        # Display list of items
        receipt_label = ctk.CTkLabel(self.root, text=receipt_text, font=("Helvetica", 20), bg_color="#F2A007", wraplength=container_width * 0.8)
        receipt_label.place(relx=0.5, rely=0.5, anchor=ctk.CENTER)
        
        # Calculate total and VAT
        total_amount = sum([float(row.split(': ')[1]) for row in receipt_details])
        vat_amount = total_amount * 0.23
        
        # Display total and VAT
        total_label = ctk.CTkLabel(self.root, text=f"Total: {total_amount:.2f} EUR", font=("Helvetica", 20), bg_color="#F2A007")
        total_label.place(relx=0.5, rely=0.8, anchor=ctk.CENTER)
        
        vat_label = ctk.CTkLabel(self.root, text=f"VAT (23%): {vat_amount:.2f} EUR", font=("Helvetica", 20), bg_color="#F2A007")
        vat_label.place(relx=0.5, rely=0.85, anchor=ctk.CENTER)
        
        imagelogo = ctk.CTkImage(Image.open("logo2.png"), size=(180, 180))
        logo = ctk.CTkLabel(master=self.root, text="", corner_radius=10, image=imagelogo, bg_color="#f2e4dc")
        logo.place(x=0, y=0)
        
        new_order_button = ctk.CTkButton(master=root, text="New Order", command=self.new_order, bg_color="#F2A007")
        new_order_button.place(relx=0.45, rely=0.9)

    def read_order_details(self):
        with open('current-customer.csv', mode='r') as file:
            reader = csv.reader(file)
            next(reader)  # Skip header row
            order_details = next(reader)
            return order_details

    def read_receipt_details(self):
        receipt_details = []
        with open('receipt-items.csv', mode='r') as file:
            reader = csv.reader(file)
            next(reader)  # Skip header row
            for row in reader:
                item = row[0]
                price = row[1]
                receipt_details.append(f"{item}: {price}")
        return receipt_details

    def new_order(self):
        root.destroy()
        import DeliveryCollection
        DeliveryCollection.DeliveryCollection1(app)
        app.mainloop()

root = ctk.CTk()
app = OrderConfirmation(root)
root.mainloop()
