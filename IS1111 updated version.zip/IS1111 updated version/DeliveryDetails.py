import customtkinter as ctk
from PIL import Image, ImageTk
import random
import csv
import phonenumbers

ctk.set_default_color_theme("green")
ctk.set_appearance_mode("light")

class delivery():
    def __init__(self, root_tk):
        self.root_tk = root_tk
        self.root_tk.geometry("700x700")
        self.root_tk.title("Details")
        self.root_tk.config(bg="#f2e4dc")
        placeholder_font = ("Verdana", 16)

        self.fname_entry = ctk.CTkEntry(master=root_tk, placeholder_text="First Name:", corner_radius=10, height=50, width=150, font=placeholder_font, border_width=0, bg_color="#f2e4dc")
        self.fname_entry.place(relx=0.27, rely=0.04)

        self.lname_entry = ctk.CTkEntry(master=root_tk, placeholder_text="Last Name:", corner_radius=10, height=50, width=150, font=placeholder_font, border_width=0, bg_color="#f2e4dc")
        self.lname_entry.place(relx=0.6, rely=0.04)

        self.area_code = ctk.CTkEntry(master=root_tk, placeholder_text="Area Code", corner_radius=10, height=50, width=100, font=placeholder_font, border_width=0, bg_color="#f2e4dc")
        self.area_code.place(relx=0.27, rely=0.15)

        self.number = ctk.CTkEntry(master=root_tk, placeholder_text="Phone Number", corner_radius=10, height=50, width=150, font=placeholder_font, border_width=0, bg_color="#f2e4dc")
        self.number.place(relx=0.6, rely=0.15)

        self.streetno = ctk.CTkEntry(master=root_tk, placeholder_text="Street No.", font=placeholder_font, corner_radius=10, height=50, width=100, border_width=0, bg_color="#f2e4dc")
        self.streetno.place(relx=0.05, rely=0.26)

        self.addressline1 = ctk.CTkEntry(master=root_tk, placeholder_text="Address Line 1.", font=placeholder_font, corner_radius=10, height=50, width=200, border_width=0, bg_color="#f2e4dc")
        self.addressline1.place(relx=0.27, rely=0.26)

        self.addressline2 = ctk.CTkEntry(master=root_tk, placeholder_text="Address Line 2.", font=placeholder_font, corner_radius=10, height=50, width=200, border_width=0, bg_color="#f2e4dc")
        self.addressline2.place(relx=0.6, rely=0.26)

        self.city = ctk.CTkEntry(master=root_tk, placeholder_text="City", font=placeholder_font, corner_radius=10, height=50, width=100, border_width=0, bg_color="#f2e4dc")
        self.city.place(relx=0.27, rely=0.36)

        self.eircode = ctk.CTkEntry(master=root_tk, placeholder_text="Eircode", font=placeholder_font, corner_radius=10, height=50, width=100, border_width=0, bg_color="#f2e4dc")
        self.eircode.place(relx=0.6, rely=0.36)

        self.ordernotes = ctk.CTkEntry(master=root_tk, placeholder_text="Back again? Share your first name & number to continue!", corner_radius=10, height=100, width=500, font=placeholder_font, border_width=2, bg_color="#f2e4dc")
        self.ordernotes.place(relx=0.15, rely=0.5)

        self.submit_button = ctk.CTkButton(master=root_tk, text="Submit", command=self.submit)
        self.submit_button.place(relx=0.4, rely=0.7)

        self.img = ctk.CTkImage(Image.open("logo2.png"), size=(150, 150))
        self.logo = ctk.CTkLabel(master=root_tk, text="", corner_radius=10, image=self.img, bg_color="#f2e4dc")
        self.logo.place(x=0, y=0)

    def submit(self):
        entered_text = self.ordernotes.get()
        if entered_text:
            name, phone_number = entered_text.split()

            if self.check_details_in_database(name, phone_number):
                self.write_current_customer_details(name, phone_number)
                # Close the current window and open the MenuPage
                self.root_tk.destroy()
                import MenuPage
                MenuPage.Menu(app)
                app.mainloop()

        # Check if the inputs for area code and number are valid
        area_code_valid = self.validate_area_code(self.area_code.get())
        number_valid = self.validate_phone_number(self.number.get())


        # Check if the inputs for first and last name are good
        fname_valid = self.validation_name_checker(self.fname_entry.get())
        lname_valid = self.validation_name_checker(self.lname_entry.get())

        address_valid = self.address_check(self.streetno.get(), self.addressline1.get(), self.addressline2.get(), self.city.get(), self.eircode.get())

        # If all inputs are valid, proceed
        if fname_valid and lname_valid and area_code_valid and address_valid and number_valid:
            receipt_number = self.generate_receipt_number()
            address = f'{self.streetno.get()}, {self.addressline1.get()}, {self.addressline2.get()}, {self.city.get()}, {self.eircode.get()}'

            # Collect all valid inputs
            data = {
                "Receipt Number": receipt_number,
                "First Name": self.fname_entry.get(),
                "Last Name": self.lname_entry.get(),
                "Area Code": self.area_code.get(),
                "Phone Number": self.number.get(),
                "Address": address
            }

            # Write data to CSV file
            with open('customer-details.csv', mode='a', newline='') as file:
                writer = csv.DictWriter(file, fieldnames=data.keys())

                # If the file is empty, write headers
                if file.tell() == 0:
                    writer.writeheader()

                # Write data to the file
                writer.writerow(data)

            # Write data to disposable database file
            with open('current-customer.csv', mode='w', newline='') as file:
                writer = csv.DictWriter(file, fieldnames=data.keys())

                # If the file is empty, write headers
                if file.tell() == 0:
                    writer.writeheader()

                # Write data to the file
                writer.writerow(data)

            # Close the current window and open the MenuPage
            self.root_tk.destroy()
            import MenuPage
            MenuPage.Menu(app)
            app.mainloop()

    def check_details_in_database(self, name, phone_number):
        # Search for the entered details in the database
        with open('customer-details.csv', mode='r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row["First Name"] == name and row["Phone Number"] == phone_number:
                    return row  # Details found in the database
        return None  # Details not found in the database

    def write_current_customer_details(self, name, phone_number):
        # Get the details from the database
        details = self.check_details_in_database(name, phone_number)
        if details:
            # Write the details to current-customer.csv
            with open('current-customer.csv', mode='w', newline='') as file_write:
                writer = csv.writer(file_write)
                writer.writerow(["Receipt Number", "First Name", "Last Name", "Area Code", "Phone Number", "Address"])
                writer.writerow([details["Receipt Number"], details["First Name"], details["Last Name"], details["Area Code"], details["Phone Number"], details["Address"]])

    def validate_area_code(self, country_input):
        try:
            # Check if the country code is valid
            if not phonenumbers.region_code_for_country_code(int(country_input)):
                return False
        except ValueError:
            return False
        return True

    def validate_phone_number(self, number):
        if not number.isdigit() or len(number) != 9:
            return False
        return True

    def generate_receipt_number(self):
        # Generate a random receipt number between 1 and 10000
        receipt_number = random.randint(1, 10000)
        return receipt_number

    def validation_name_checker(self, name):
        if len(name.strip()) > 30 or len(name.strip()) == 0:
            print("\nSorry your invalid name length.")
            return False
        return True

    def address_check(self, streetNo, addressLine1, addressLine2, city, eircode):
        if not streetNo.isdigit():
            print("Please enter a valid numerical street number!")
            return False

        if not all((addressLine1, addressLine2, city)):
            print("Please enter a valid address!")
            return False

        if len(eircode.upper()) != 7:
            print("Please enter a valid Eircode!")
            return False

        return True

    


root_tk = ctk.CTk()
app = delivery(root_tk)
root_tk.mainloop()